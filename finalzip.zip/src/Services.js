import React from 'react';

const Services = () => {
  return (
    <div>
      <h2>Our Services</h2>
      <p>Details about the services...</p>
    </div>
  );
};

export default Services;
